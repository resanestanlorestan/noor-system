self.__MIDDLEWARE_MATCHERS = [
  {
    "regexp": "^(?:\\/(_next\\/data\\/[^/]{1,}))?(?:\\/((?!_next\\/static|_next\\/image|favicon.ico|images|fonts|docs|api\\/health|.*\\.(?:png|jpg|jpeg|svg|ico|css|js|mjs|woff2?|ttf)$).*))(\\.json|\\.rsc|\\.segments\\/.+\\.segment\\.rsc)?[\\/#\\?]?$",
    "originalSource": "/((?!_next/static|_next/image|favicon.ico|images|fonts|docs|api/health|.*\\.(?:png|jpg|jpeg|svg|ico|css|js|mjs|woff2?|ttf)$).*)"
  }
];self.__MIDDLEWARE_MATCHERS_CB && self.__MIDDLEWARE_MATCHERS_CB()