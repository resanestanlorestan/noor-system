module.exports=[30660,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_register_upload_route_actions_15wnvf6mowzxk.js.map