module.exports=[69672,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_cases_route_actions_1vd8k_y-aqw4q.js.map