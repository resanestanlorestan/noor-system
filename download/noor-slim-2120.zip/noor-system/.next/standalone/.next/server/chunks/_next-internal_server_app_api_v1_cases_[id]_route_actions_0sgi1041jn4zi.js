module.exports=[66292,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_cases_%5Bid%5D_route_actions_0sgi1041jn4zi.js.map