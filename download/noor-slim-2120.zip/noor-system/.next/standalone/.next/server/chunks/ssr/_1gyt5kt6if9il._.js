(()=>{"use strict";module.exports=[58983,a=>{var b=a.i(64831);let c={name:"loader-circle",size:24,node:[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],aliases:["loader-2"]};c.node;let d=(0,b.f)(c);a.s(["f",0,d],58983)},8395,a=>{a.s(["f",0,{}])}]})();

//# sourceMappingURL=_1gyt5kt6if9il._.js.map