globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/bAmSJ7cuWtRxFTKnnWdDS/_buildManifest.js",
    "static/bAmSJ7cuWtRxFTKnnWdDS/_ssgManifest.js",
    "static/bAmSJ7cuWtRxFTKnnWdDS/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1ckvzn7sfprko.js",
    "static/chunks/2ojf3r8g4tn7s.js",
    "static/chunks/0tb2jgjhnzx09.js",
    "static/chunks/216iyidhmrh3u.js",
    "static/chunks/2734-n7wxsngt.js",
    "static/chunks/turbopack-2c3mg3r-05n1w.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/account/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/audit/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/broadcasts/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/case-status/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/cases/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/cases/[id]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/cases/[id]/dossier/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/cases/[id]/edit/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/cases/[id]/steps/[step]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/cases/claim/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/cases/new/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/dashboard/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/dashboard/api-management/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/events/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/notifications/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/outbox/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/permissions/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/ranking/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/reminders/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/reports/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/settings/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/sms/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/users/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/users/[id]/edit/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(workspace)/users/new/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/forgot-password/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/login/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/register/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/register/verify/[token]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/reset-password/[token]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/setup/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/verify-email/[token]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2ojf3r8g4tn7s.js",
        "static/chunks/0tb2jgjhnzx09.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/2734-n7wxsngt.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
