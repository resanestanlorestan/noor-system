var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[externals]__217xr9d03dxhj._.js")
R.c("server/chunks/node_modules_next_dist_182yaz9b1ql64._.js")
R.c("server/chunks/[root-of-the-server]__02_2sm-ocfxhk._.js")
R.c("server/chunks/_1u8vmcgae9eor._.js")
R.c("server/chunks/_1y5_49ip8l9oe._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_1ryftkbeskq31.js")
R.m(43007)
module.exports=R.m(43007).exports
